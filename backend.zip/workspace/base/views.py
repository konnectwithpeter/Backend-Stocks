import os
import re
import threading
import time
from re import search, sub
from threading import Timer

import pytz
from backend.settings import EMAIL_HOST_USER
from django.contrib.sites.shortcuts import get_current_site
from django.core.mail import EmailMessage, EmailMultiAlternatives, send_mail
from django.db.models.functions import Now
from django.dispatch import receiver
from django.http import HttpResponsePermanentRedirect
from django.shortcuts import render
from django.template.loader import get_template, render_to_string
from django.urls import reverse
from django.utils.encoding import (DjangoUnicodeDecodeError, smart_bytes,
                                   smart_str)
from django.utils.html import strip_tags
from django.utils.http import urlsafe_base64_decode, urlsafe_base64_encode
from rest_framework import generics, status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from rest_framework_simplejwt.views import TokenObtainPairView

from base.models import *
from base.serializers import *


class MyTokenObtainPairSerializer(TokenObtainPairSerializer):
    @classmethod
    def get_token(cls, user):
        token = super().get_token(user)

        token['username'] = user.username
        token['email'] = user.email
        # token['is_staff'] = user.is_staff
        return token


class MyTokenObtainPairView(TokenObtainPairView):
    serializer_class = MyTokenObtainPairSerializer


class RegisterView(generics.GenericAPIView):
    permission_classes = [AllowAny]

    serializer_class = RegisterUserSerializer

    def post(self, request):
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        email = request.data['email']
        user = request.data['username']

     
        def new_task(mail):
            time.sleep(5)
            message = render_to_string(
                'base/welcome_email.html', {'username': user})
            msg = EmailMessage(
                'Welcome to Xtatic',
                message,
                EMAIL_HOST_USER,
                [mail],
            )
            msg.content_subtype = "html"
            msg.send()

        task = threading.Thread(target=new_task, args=(email,))
        task.start()
        return Response(status=status.HTTP_201_CREATED)

class RequestPasswordResetEmail(generics.GenericAPIView):
    serializer_class = ResetPasswordEmailRequestSerializer
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = self.serializer_class(data=request.data)
        email = request.data.get('email', '')

        if User.objects.filter(email=email).exists():
            user = User.objects.get(email=email)
            uidb64 = urlsafe_base64_encode(smart_bytes(user.id))
            token = PasswordResetTokenGenerator().make_token(user)
            current_site = get_current_site(request=request).domain
            # current_site = "localhost:5000"
            # relativeLink = reverse(
            #     'password-reset-confirm', kwargs={'uidb64': uidb64, 'token': token})
            redirect_url = request.data.get('redirect_url', '')
            reset_url = redirect_url+'uidb64='+str(uidb64)+'/token='+str(token)

            # absurl = 'http://localhost:5000/'
            message = ""
            # email_body = 'Hello,\nUse link below to reset your password \n' + reset_url

            send_mail(
                "Password Reset",
                message,
                EMAIL_HOST_USER,
                [email],
                html_message=render_to_string(
                    'base/user_reset_password.html', {'reset_url': reset_url}),
                fail_silently=False,
            )

        return Response({'success': 'We have sent you a link to reset your password'}, status=status.HTTP_200_OK)


class CustomRedirect(HttpResponsePermanentRedirect):

    allowed_schemes = [os.environ.get('APP_SCHEME'), 'http', 'https']


class PasswordTokenCheckAPI(generics.GenericAPIView):
    serializer_class = SetNewPasswordSerializer
    permission_classes = [AllowAny]

    def get(self, request, uidb64, token):

        redirect_url = request.GET.get('redirect_url')

        try:
            id = smart_str(urlsafe_base64_decode(uidb64))
            user = User.objects.get(id=id)

            if not PasswordResetTokenGenerator().check_token(user, token):
                if len(redirect_url) > 3:
                    return CustomRedirect(redirect_url+'?token_valid=False')
                else:
                    return CustomRedirect(os.environ.get('FRONTEND_URL', '')+'?token_valid=False')

            if redirect_url and len(redirect_url) > 3:
                return CustomRedirect(redirect_url+'?token_valid=True&message=Credentials Valid&uidb64='+uidb64+'&token='+token)
            else:
                return CustomRedirect(os.environ.get('FRONTEND_URL', '')+'?token_valid=False')

        except DjangoUnicodeDecodeError as identifier:
            try:
                if not PasswordResetTokenGenerator().check_token(user):
                    return CustomRedirect(redirect_url+'?token_valid=False')

            except UnboundLocalError as e:
                return Response({'error': 'Token is not valid, please request a new one'}, status=status.HTTP_400_BAD_REQUEST)


class SetNewPasswordAPIView(generics.GenericAPIView):
    serializer_class = SetNewPasswordSerializer
    permission_classes = [AllowAny]

    def patch(self, request):
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)
        return Response({'success': True, 'message': 'Password reset success'}, status=status.HTTP_200_OK)

@api_view(['GET', 'POST', 'DELETE'])
@permission_classes([IsAuthenticated])
def investment_view(request):
    if request.method == 'GET':
        user = request.user
        response = user.investment_set.all()
        serializer = InvestmentSerializer(response, many=True)
        return Response(serializer.data)
    if request.method == 'POST':
        stk = Stock.objects.get(stock=request.data['stock'])
        if Investment.objects.filter(investor=request.user, principal = request.data['principal'], stock = stk).exists():
            return Response()
        else:
            Investment.objects.create(investor=request.user, timestamp=request.data['timestamp'], principal = request.data['principal'], stock = stk) 
            return Response()
    if request.method == 'DELETE':
        user = request.user     
        a = user.investment_set.all().filter(stock=request.data['stock'])
        a.delete()
        return Response()


@api_view(['GET', 'POST', 'PUT', 'DELETE'])
@permission_classes([IsAuthenticated])
def portfolio_view(request):
    if request.method == 'GET':
        user = request.user
        response = PortFolio.objects.all().filter(investor=user)
        print(response)
        serializer = PortFolioSerializer(response, many=True)
        return Response(serializer.data)  
