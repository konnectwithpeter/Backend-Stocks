from core.models import *
from django.contrib.auth.models import AbstractUser
from django.db import models
from shortuuidfield import ShortUUIDField
from django.utils.translation import gettext as _
from django.db.models.signals import pre_save

from .managers import CustomUserManager

import yfinance as yf
import pandas as pd
import datetime



class User(AbstractUser):
    id = ShortUUIDField(unique=True, max_length=10, editable=False, null=True)
    username = models.CharField(max_length=200,  unique=True, primary_key=True)
    email = models.EmailField(_('email address'), unique=True)
    is_staff = models.BooleanField(default=False)
    is_superuser = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    last_login = models.DateTimeField(
        auto_now_add=True, verbose_name='last login')
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['username']

    objects = CustomUserManager()

    def __str__(self):
        return self.username

class PortFolio(models.Model):
    investor = models.OneToOneField(User, on_delete=models.SET_NULL, blank=True, null=True)
    invested = models.ManyToManyField('core.Stock', blank=True,)
    updated = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ('-updated',)

    def __str__(self):
        return self.investor.username        

class Investment(models.Model):
    investor = models.ForeignKey(User, on_delete=models.CASCADE, blank=True, null=True)
    stock = models.ForeignKey('core.Stock', on_delete=models.CASCADE, blank=True, null=True)
    timestamp = models.DateTimeField(null=True, blank=True)
    principal = models.FloatField(null=True, blank=True)
    market_cap = models.FloatField(null=True, blank=True)

    class Meta:
        unique_together = ['stock', 'investor']
        ordering = ('-timestamp',)

    def __str__(self):
        return str(self.investor)


def pre_save_receiver(sender, instance, *args, **kwargs):
    date_string = str(instance.timestamp)
    #print("date:",datetime.datetime.fromtimestamp(date_string,"%Y-%m-%d %H:%M:%S")) 
    date = datetime.datetime.strptime(date_string[:10],"%Y-%m-%d")-datetime.timedelta(days=1)
    
    print(instance)
    df = yf.download(str(instance.stock), start=date, end=instance.timestamp)
   
    if len(df) > 0:
        instance.market_cap=df.iloc[-1]['Close']
    else:
        instance.principal =0  
   
    if  PortFolio.objects.filter(investor=instance.investor).exists():
        if not PortFolio.objects.filter(investor=instance.investor, invested=instance.stock).exists():
            a = PortFolio.objects.get(investor=instance.investor)
            a.invested.add(instance.stock)
    else:
        PortFolio.objects.create(investor=instance.investor)         
        a = PortFolio.objects.get(investor=instance.investor)        
        a.invested.add(instance.stock)
      

pre_save.connect(pre_save_receiver, sender=Investment)        

